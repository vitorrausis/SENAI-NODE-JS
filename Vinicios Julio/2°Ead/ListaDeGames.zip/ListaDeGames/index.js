//carregando o express
const express = require("express");
//instanciando o express e carregando a biblioteca do express dentro dessa cons app
const app = express();

//Lista de Games

let games = [
    {title: "sea Of Thieves" , Studio: "Rare", price: 30},
    {title: "WOW" , Studio: "Blizzard", price: 120},
    {title: "Valorant" , Studio: "Riot", price: 0},
    {title: "COD" , Studio: "Activision", price: 200},
    {title: "Minecraft" , Studio: "Mojang", price: 80},
    {title: "Halo" , Studio: "Microsoft", price: 90},
    {title: "Halo" , Studio: "Microsoft", price: 90},
    {title: "Halo" , Studio: "Microsoft", price: 90},
    {title: "Halo" , Studio: "Microsoft", price: 90},
    {title: "Halo" , Studio: "Microsoft", price: 90},

];

app.listen(3080,() =>{
    console.log("Servidor rodando");
});
app.get("/", (req, res) => {
    res.json(games);
});