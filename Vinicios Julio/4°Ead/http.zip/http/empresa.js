import express from "express";

const app = express();

app.listen(3000,() =>
console.log('servidor iniciado na porta 3000')
);

app.get('/',(req, res) =>
res.send('<h1 style ="color: red">Página Empresa</h1>')
);